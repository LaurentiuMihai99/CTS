package cts.naum.laurentiu.g1093.pattern.factory;

public class JuniorAccount extends BankAccount {

	public JuniorAccount(double Balance, String Id) {
		super(Balance, Id);
	}

}
