package cts.naum.laurentiu.g1093.pattern.command;

public interface AsyncTaskInterface {
	public void startTask();
}
