package cts.naum.laurentiu.g1093.pattern.factory;

public enum AccountType {
	DEBIT,CREDIT,JUNIOR 
}
